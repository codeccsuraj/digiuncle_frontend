import { Cart } from "../pages";

const privateRoutes = [
    {
        path : "/cart",
        element : <Cart />,
    },
];

export {privateRoutes};