// import carousal_img1 from '../assets/banner/car-1.png';
// import carousal_img2 from '../assets/banner/car-2.png';
// import carousal_img3 from '../assets/banner/car-3.png';
// import carousal_img4 from '../assets/banner/car-4.png';

const slides = [
    {
        id : 1,
        image : "https://rb.gy/z0196x",
      },
      {
        id : 2,
        image : "https://rb.gy/x7i0z1",
      },
      {
        id : 3,
        image : "https://shorturl.at/eqyGH",
      },
      {
        id : 4,
        image : "https://shorturl.at/chnF0",
      },
]

export {slides}